export default class GameCanvas{
    constructor(){
       
    }

    run(){
        
    }
 

}