import GameCanvas from "./panel/game-canvas.js"
import StoryCanvas from "./panel/story-canvas.js";

const gameCanvas = new GameCanvas();
const storyCanvas = new StoryCanvas();
const pighomegameCanvas = document.querySelector(".pighomegame-canvas");       

window.addEventListener("load",function(){
       storyCanvas.checkCurPage = (e) => {
              storyCanvas.dom.classList.add("d-none");              
              pighomegameCanvas.classList.remove("d-none");                     
              
       }

       gameCanvas.run();
       storyCanvas.run();
})
// pighomegameCanvas.style.display === 'none' &&
// window.addEventListener("keydown", function(e){      
//        if(  pighomegameCanvas.style.display === 'none' &&e.keyCode === 13){
//               console.log("enter키 작동중");
//               e.preventDefault();
//               e.returnValue = false;
//        }
// })