export default class Button{

  constructor() {

  }

  




}